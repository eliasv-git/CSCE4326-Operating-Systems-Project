#ifndef AUTH_H
#define AUTH_H

// Declare the authenticateUser function
bool authenticateUser();

#endif
